Mypackage
---------

install the package using
	$ pip install Mypackage

Execute command
	$ shell

You will see a prompt (Cmd)
	Execute commands.

	1.(Cmd) greet

	2.(Cmd) stock company_symbol

To exit from shell use Ctrl+d
